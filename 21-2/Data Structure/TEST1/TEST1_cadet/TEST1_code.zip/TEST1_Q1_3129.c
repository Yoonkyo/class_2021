#include <stdio.h>
int main(){
    int n,number;
    int sum=0;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++){ 
        scanf("%d",&number);   
        sum=sum+number;
    }
    printf("%d",sum);
    return 0;
}