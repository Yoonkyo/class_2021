include <stdio.h>

int main(){ 
    int n,max;
    int array[];  
    for(int i=0;i<sizeof(array)/sizeof(int);i++){ 
        scanf("%d",&n);   
        int array[n]=;
    }
        max=array[0];
    for(int i=0;i<sizeof(array)/sizeof(int);i++){
        if(max<array[i]){
        max=array[i];
        return 0;
    }
    printf("%d",max);
    return 0;
}